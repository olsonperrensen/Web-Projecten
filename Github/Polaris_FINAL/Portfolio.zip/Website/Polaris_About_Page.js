function myFn() {
$('.p1').css('border', '6px solid white')
}
function myFn2(){
    $('.p2').css('border', '6px double white')
}
function myFn3(){
    $('.p3').css('border', '6px dashed white')
}